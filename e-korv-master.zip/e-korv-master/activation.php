<?
require('DATA/function.php'); 

activation();

echo $err;
?>